# Fluzzy Bloom website

A responsive one-page portfolio website for Fluzzy Bloom, featuring the 12 supplied handmade pipe-cleaner flower photos.

## Preview locally
Open `index.html` in a browser.

## Publish free with GitHub Pages
1. Sign in to GitHub and create a new **public** repository (for example, `fluzzy-bloom`).
2. Upload `index.html` and the entire `assets` folder from this package. Keep the folder structure unchanged.
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
5. Wait for GitHub Pages to publish. Your site address will look like `https://YOUR-USERNAME.github.io/fluzzy-bloom/`.

## Customising
- Replace any image in `assets` with your new photo using the same filename to update it without editing the page.
- To add more photos, copy an image into `assets` and duplicate one `<article class="work-card">...</article>` in `index.html`, updating its image filename, alt text, and title.
- The Instagram DM links already point to `https://www.instagram.com/fuzzy_bloom._?cplk=MTJyaXNlZ200MjV3Zw==`.
- No prices are shown because only one supplied photo included a visible price; message through Instagram for current pricing and availability.
